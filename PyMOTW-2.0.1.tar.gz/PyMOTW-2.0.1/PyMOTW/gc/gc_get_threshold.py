#!/usr/bin/env python
# encoding: utf-8
#
# Copyright (c) 2010 Doug Hellmann.  All rights reserved.
#
"""Show the default thresholds.
"""
#end_pymotw_header

import gc

print gc.get_threshold()
